var searchData=
[
  ['backtracking_0',['Backtracking',['../class_backtracking.html',1,'']]],
  ['ball_1',['Ball',['../class_ball.html',1,'']]]
];
