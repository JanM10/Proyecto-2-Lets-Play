var searchData=
[
  ['backtracking_10',['Backtracking',['../class_backtracking.html',1,'']]],
  ['ball_11',['Ball',['../class_ball.html',1,'']]]
];
