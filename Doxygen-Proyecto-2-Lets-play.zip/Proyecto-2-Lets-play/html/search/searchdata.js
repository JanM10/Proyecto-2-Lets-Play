var indexSectionsWithContent =
{
  0: "bcmptw",
  1: "bcmptw",
  2: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

